<?php
//Memastikan file ini tidak diakses secara langsung (direct access is not allowed)
defined( 'validSession' ) or die( 'Restricted access' ); 

class c_student
{
	var $strResults="";
	
	function validateRuangLingkup(&$params) 
	{
		$temp=TRUE;
		//Jika mode Add, nama harus diisi
		if(strlen(trim($params["txtNama"]))=="")
		{
			$this->strResults.="Nama ruang lingkup tidak valid!<br/>";
			$temp=FALSE;
		}
		return $temp;
	}
	
	function validateDeleteRuangLingkup($kode) 
	{
		global $dbLink;
		
		$temp=TRUE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}
		
		return $temp;
	}

	function checkDeleteRuangLingkup($kode)
	{
		global $dbLink;
		
		$q = "SELECT id FROM ruang_lingkup WHERE id='".$kode."'";
		$result=mysql_query($q, $dbLink);
		while($query_data=mysql_fetch_row($result))
		{ $ruang_lingkup =  $query_data[0]; }
		
		$rsTemp=mysql_query("SELECT COUNT(ruang_lingkup_id) FROM ekstra Where ruang_lingkup_id LIKE '".$ruang_lingkup.".%'");
		if($query_data=mysql_fetch_row($rsTemp))
		{
			if ($query_data[0]==0)
				$temp = TRUE;
			else
				$temp = FALSE;
		}
		return $temp;
	}
	
	function addRuangLingkup(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateRuangLingkup($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Tambah Data Ruang Lingkup - ".$this->strResults;
			return $this->strResults;
		}

		$nama=$params["txtNama"];
	
		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$nama = stripslashes($nama);
		}

		$nama=mysql_real_escape_string($nama, $dbLink);		
		$nama = strip_html_tags($nama);	
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$rsTemp=mysql_query("SELECT nama FROM ruang_lingkup WHERE nama='".$nama."'", $dbLink);
			if(mysql_num_rows($rsTemp)>0)
			{
				throw new Exception('Nama ruang lingkup sudah digunakan. Silakan gunakan nama yang belum terpakai.');
			}
			else
			{ 
				$q = "INSERT INTO ruang_lingkup (nama, aktif) ";
				$q.= "VALUES ('".$nama."', 'Y');";
			
				if (!mysql_query( $q, $dbLink))
				{	throw new Exception('Gagal menambah database'); }
			}
			$this->strResults="Sukses Tambah Data Ruang Lingkup ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			$this->strResults="Gagal Tambah Data Ruang Lingkup - ".$e->getMessage().'<br/>';
			$result = @mysql_query('ROLLBACK', $dbLink);
			$result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		return $this->strResults;
	}
	
	function editRuangLingkup(&$params)  
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateRuangLingkup($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Ubah Data Ruang Lingkup - ".$this->strResults;
			return $this->strResults;
		}

		$id = $params["txtId"];
		$nama = $params["txtNama"];
		
		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$id = stripslashes($id);
			$nama = stripslashes($nama);
		}

		$id=mysql_real_escape_string($id, $dbLink);
		$nama=mysql_real_escape_string($nama, $dbLink);
		$id = strip_html_tags($id);
		$nama = strip_html_tags($nama);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE ruang_lingkup SET nama='".$nama."'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query( $q, $dbLink))
			{
				throw new Exception('Tidak dapat mengubah data ruang lingkup di database.');
			}
			$this->strResults="Sukses Ubah Data Ruang Lingkup ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Ubah Data Ruang Lingkup - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}
	
	function deleteRuangLingkup(&$params)
	{
		global $dbLink;

		$id = $params["txtId"];

		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateDeleteRuangLingkup($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Ruang Lingkup - ".$this->strResults;
			return $this->strResults;
		}
		
		if(!$this->checkDeleteRuangLingkup($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Ruang Lingkup - ".$this->strResults;
			$this->strResults.="Ruang lingkup masih memiliki Esktrakurikuler. Hapus ekstrakurikuler yang terkait lebih dulu!<br/>";
			return $this->strResults;
		}
		
		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc($id)) 
		{
			$id = stripslashes($id);
		}
		$id = mysql_real_escape_string($id, $dbLink);
		$id = strip_html_tags($id);

		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE ruang_lingkup SET aktif='T'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat menghapus data ruang lingkup di database.');
			}
			$this->strResults="Sukses Hapus Data Ruang Lingkup ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Hapus Data Ruang Lingkup - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}
        
    function validatePosisi(&$params) 
	{
		$temp=TRUE;
		//kode grup harus diisi
		if($params["txtNama"]=='')
		{
			$this->strResults.="Nama posisi harus diisi!<br/>";
			$temp=FALSE;
		}

		return $temp;
	}
	
	function validateDeletePosisi($kode) 
	{
		$temp=TRUE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}
		
		return $temp;
	}
	
	function addPosisi(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validatePosisi($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Tambah Data Posisi - ".$this->strResults;
			return $this->strResults;
		}

		$nama = $params["txtNama"];
		
		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$nama = stripslashes($nama);
		}
		$nama=mysql_real_escape_string($nama, $dbLink);
		$nama = strip_html_tags($nama);

		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$rsTemp=mysql_query("SELECT nama FROM posisi WHERE nama='".$nama."'", $dbLink);
			if(mysql_num_rows($rsTemp)>0)
			{
				throw new Exception('Nama posisi sudah digunakan. Silakan gunakan nama yang belum terpakai.');
			}
			else
			{ 
				$q = "INSERT INTO posisi (nama, aktif) ";
				$q.= "VALUES ('".$nama."', 'Y');";
			
				if (!mysql_query( $q, $dbLink))
				{	throw new Exception('Gagal menambah database'); }
			}
			$this->strResults="Sukses Tambah Data Posisi ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			$this->strResults="Gagal Tambah Data Posisi - ".$e->getMessage().'<br/>';
			$result = @mysql_query('ROLLBACK', $dbLink);
			$result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		return $this->strResults;
	}
	
	function editPosisi(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validatePosisi($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Ubah Data Posisi - ".$this->strResults;
			return $this->strResults;
		}
		$id = $params["txtId"];
		$nama = $params["txtNama"];		
		
		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$id = stripslashes($id);
			$nama = stripslashes($nama);
		}
		$id=mysql_real_escape_string($id, $dbLink);
		$nama=mysql_real_escape_string($nama, $dbLink);
		$id = strip_html_tags($id);
		$nama = strip_html_tags($nama);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE posisi SET nama='".$nama."'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query( $q, $dbLink))
			{
				throw new Exception('Tidak dapat mengubah data posisi di database.');
			}
			$this->strResults="Sukses Ubah Data Posisi ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Ubah Data Posisi - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}
	
	function deletePosisi(&$params)
	{
		global $dbLink;

		$id = $params["txtId"];

		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateDeletePosisi($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Posisi - ".$this->strResults;
			return $this->strResults;
		}

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc($id)) 
		{
			$id = stripslashes($id);
		}
		$id = mysql_real_escape_string($id, $dbLink);
		$id = strip_html_tags($id);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE posisi SET aktif='T'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat menghapus data posisi di database.');
			}
			$this->strResults="Sukses Hapus Data Posisi ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Hapus Data Posisi - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}
        
    function validateEkstra(&$params) 
	{
		$temp=TRUE;
		//nama ekstra harus diisi
		if($params["txtNama"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Nama ekstrakurikuler harus diisi!<br/>";
			$temp=FALSE;
		}

		//jenis harus diisi
		if($params["rdoJenis"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Jenis harus diisi!<br/>";
			$temp=FALSE;
		}
		
		//ruang lingkup harus diisi
		if($params["cboRuangLingkup"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Ruang lingkup harus diisi!<br/>";
			$temp=FALSE;
		}
		return $temp;
	}
	
	function validateDeleteEkstra($kode) 
	{
		global $dbLink;
		
		$temp=FALSE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}

		$rsTemp=mysql_query("SELECT ekstra_id FROM ekstra_mahasiswa WHERE ekstra_id='".$kode."'", $dbLink);
		$count = mysql_num_rows($rsTemp);
		if($count==0)
			$temp = TRUE;
		else
		{
			$temp = FALSE;
			$this->strResults="Ekstrakurikuler masih memiliki mahasiswa. Hapus Ekstra Mahasiswa yang terkait dengan Ekstra ini terlebih dahulu.<br>";
		}
		
		return $temp;
	}
	
	function addEkstra(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateEkstra($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Tambah Data Ekstrakurikuler - ".$this->strResults;
			return $this->strResults;
		}
		$nama = $params["txtNama"];
		$jenis = $params["rdoJenis"];
		$ruang_lingkup = $params["cboRuangLingkup"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$nama = stripslashes($nama);
			$jenis = stripslashes($jenis);
			$ruang_lingkup = stripslashes($ruang_lingkup);
		}
		$nama=mysql_real_escape_string($nama, $dbLink);
		$jenis=mysql_real_escape_string($jenis, $dbLink);
		$ruang_lingkup=mysql_real_escape_string($ruang_lingkup, $dbLink);

		$nama=strip_html_tags($nama);
		$jenis=strip_html_tags($jenis);
		$ruang_lingkup=strip_html_tags($ruang_lingkup);

		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$rsTemp=mysql_query("SELECT nama FROM ekstra WHERE nama='".$nama."'", $dbLink);
			if(mysql_num_rows($rsTemp)>0)
			{
				throw new Exception('Nama ekstrakurikuler sudah digunakan. Silakan gunakan nama yang belum terpakai.');
			}
			else
			{ 
				$q = "INSERT INTO ekstra (nama, jenis, aktif, ruang_lingkup_id) ";
				$q.= "VALUES ('".$nama."','".$jenis."','Y', '".$ruang_lingkup."');";
			
				if (!mysql_query( $q, $dbLink))
				{	throw new Exception('Gagal menambah database'); }
			}
			$this->strResults="Sukses Tambah Data Ekstrakurikuler ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			$this->strResults="Gagal Tambah Data Ekstra - ".$e->getMessage().'<br/>';
			$result = @mysql_query('ROLLBACK', $dbLink);
			$result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		return $this->strResults;
	}
	
	function editEkstra(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateEkstra($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Ubah Data Ekstrakurikuler - ".$this->strResults;
			return $this->strResults;
		}
		$id = $params["txtId"];
		$nama = $params["txtNama"];
		$jenis = $params["rdoJenis"];
		$ruang_lingkup = $params["cboRuangLingkup"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$id = stripslashes($id);
			$nama = stripslashes($nama);
			$jenis = stripslashes($jenis);
			$ruang_lingkup = stripslashes($ruang_lingkup);
		}
		$id = stripslashes($id);
		$nama=mysql_real_escape_string($nama, $dbLink);
		$jenis=mysql_real_escape_string($jenis, $dbLink);
		$ruang_lingkup=mysql_real_escape_string($ruang_lingkup, $dbLink);

		$id = stripslashes($id);
		$nama=strip_html_tags($nama);
		$jenis=strip_html_tags($jenis);
		$ruang_lingkup=strip_html_tags($ruang_lingkup);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE ekstra SET nama='".$nama."', jenis='".$jenis."', ruang_lingkup_id='".$ruang_lingkup."'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query( $q, $dbLink))
			{
				throw new Exception('Tidak dapat mengubah data ekstrakurikuler di database.');
			}
			$this->strResults="Sukses Ubah Data Ekstrakurikuler ". $jenis;
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Ubah Data Ekstrakurikuler - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}
	
	function deleteEkstra(&$params)
	{
		global $dbLink;

		$id = $params['txtId'];

		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateDeleteEkstra($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Group - ".$this->strResults;
			return $this->strResults;
		}

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc($id)) 
		{
			$id = stripslashes($id);
		}
		$id = mysql_real_escape_string($id, $dbLink);
		$id = strip_html_tags($id);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE ekstra SET aktif='T'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat menghapus data ekstrakurikuler di database.');
			}
			$this->strResults="Sukses Hapus Data Ekstrakurikuler ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Hapus Data Ekstrakurikuler - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}

	function validatePkm(&$params) 
	{
		$temp=TRUE;
		//nama ekstra harus diisi
		if($params["txtNama"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Nama PKM harus diisi!<br/>";
			$temp=FALSE;
		}
		
		return $temp;
	}
	
	function validateDeletePkm($kode) 
	{
		global $dbLink;
		
		$temp=FALSE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}

		$rsTemp=mysql_query("SELECT pkm_id FROM pkm_mahasiswa WHERE pkm_id='".$kode."'", $dbLink);
		$count = mysql_num_rows($rsTemp);
		if($count==0)
			$temp = TRUE;
		else
		{
			$temp = FALSE;
			$this->strResults="PKM masih memiliki mahasiswa. Hapus PKM Mahasiswa yang terkait dengan PKM ini terlebih dahulu.<br>";
		}
		
		return $temp;
	}
	
	function addPkm(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validatePkm($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Tambah Data PKM - ".$this->strResults;
			return $this->strResults;
		}
		$nama = $params["txtNama"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$nama = stripslashes($nama);
		}
		$nama=mysql_real_escape_string($nama, $dbLink);
		$nama=strip_html_tags($nama);

		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$rsTemp=mysql_query("SELECT nama FROM pkm WHERE nama='".$nama."'", $dbLink);
			if(mysql_num_rows($rsTemp)>0)
			{
				throw new Exception('Nama PKM sudah digunakan. Silakan gunakan nama yang belum terpakai.');
			}
			else
			{ 
				$q = "INSERT INTO pkm (nama, aktif) ";
				$q.= "VALUES ('".$nama."','Y');";
			
				if (!mysql_query( $q, $dbLink))
				{	throw new Exception('Gagal menambah database'); }
			}
			$this->strResults="Sukses Tambah Data PKM ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			$this->strResults="Gagal Tambah Data PKM - ".$e->getMessage().'<br/>';
			$result = @mysql_query('ROLLBACK', $dbLink);
			$result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		return $this->strResults;
	}
	
	function editPkm(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validatePkm($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Ubah Data PKM - ".$this->strResults;
			return $this->strResults;
		}
		$id = $params["txtId"];
		$nama = $params["txtNama"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$id = stripslashes($id);
			$nama = stripslashes($nama);
		}
		$id = stripslashes($id);
		$nama=mysql_real_escape_string($nama, $dbLink);

		$id = stripslashes($id);
		$nama=strip_html_tags($nama);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE pkm SET nama='".$nama."'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query( $q, $dbLink))
			{
				throw new Exception('Tidak dapat mengubah data PKM di database.');
			}
			$this->strResults="Sukses Ubah Data PKM ". $jenis;
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Ubah Data PKM - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}
	
	function deletePkm(&$params)
	{
		global $dbLink;

		$id = $params['txtId'];

		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateDeletePkm($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Group - ".$this->strResults;
			return $this->strResults;
		}

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc($id)) 
		{
			$id = stripslashes($id);
		}
		$id = mysql_real_escape_string($id, $dbLink);
		$id = strip_html_tags($id);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE pkm SET aktif='T'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat menghapus data PKM di database.');
			}
			$this->strResults="Sukses Hapus Data PKM ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Hapus Data PKM - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}

	function validateKompetensi(&$params) 
	{
		$temp=TRUE;
		//nama kompetensi harus diisi
		if($params["txtNama"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Nama kompetensi harus diisi!<br/>";
			$temp=FALSE;
		}
		//level diisi
		if($params["rdoLevel"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Level harus diisi!<br/>";
			$temp=FALSE;
		}
		//jenis harus diisi
		if($params["rdoJenis"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Jenis harus diisi!<br/>";
			$temp=FALSE;
		}

		return $temp;
	}

	function validateKompetensiEdit(&$params) 
	{
		$temp=TRUE;
		//nama kompetensi harus diisi
		if($params["txtNama"]=="" && $params['txtMode'] == "Edit")
		{
			$this->strResults.="Nama kompetensi harus diisi!<br/>";
			$temp=FALSE;
		}
		//level diisi
		if($params["rdoLevel"]=="" && $params['txtMode'] == "Edit")
		{
			$this->strResults.="Level harus diisi!<br/>";
			$temp=FALSE;
		}
		//jenis harus diisi
		if($params["rdoJenis"]=="" && $params['txtMode'] == "Edit")
		{
			$this->strResults.="Jenis harus diisi!<br/>";
			$temp=FALSE;
		}

		return $temp;
	}
	
	function validateDeleteKompetensi($kode) 
	{
		global $dbLink;
		
		$temp=FALSE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}

		$rsTemp=mysql_query("SELECT kompetensi_id FROM syarat_ekstra WHERE kompetensi_id='".$kode."'", $dbLink);
		$count = mysql_num_rows($rsTemp);
		if($count==0)
			$temp = TRUE;
		else
		{
			$temp = FALSE;
			$this->strResults="Kompetensi masih memiliki syarat. Hapus Syarat Ekstrakurikuler yang terkait dengan Kompetensi ini terlebih dahulu.<br>";
		}
		
		return $temp;
	}

	function checkDeleteKompetensi($kode) 
	{
		global $dbLink;
		
		$temp=FALSE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}

		$rsTemp=mysql_query("SELECT kompetensi_id FROM sertifikat WHERE kompetensi_id='".$kode."'", $dbLink);
		$count = mysql_num_rows($rsTemp);
		if($count==0)
			$temp = TRUE;
		else
		{
			$temp = FALSE;
			$this->strResults="Kompetensi masih memiliki mahasiswa. Hapus Sertifikat yang terkait dengan Kompetensi ini terlebih dahulu.<br>";
		}
		
		return $temp;
	}
	
	function addKompetensi(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateKompetensi($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Tambah Data Kompetensi - ".$this->strResults;
			return $this->strResults;
		}
		$nama = $params["txtNama"];
		$desc = $params["txtDesc"];
		$level = $params["rdoLevel"];
		$jenis = $params["rdoJenis"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$nama = stripslashes($nama);
			$desc = stripslashes($desc);
			$level = stripslashes($level);
			$jenis = stripslashes($jenis);
		}
		$nama=mysql_real_escape_string($nama, $dbLink);
		$desc = mysql_real_escape_string($desc, $dbLink);
		$level = mysql_real_escape_string($level, $dbLink);
		$jenis = mysql_real_escape_string($jenis, $dbLink);

		$nama=strip_html_tags($nama);
		$desc = strip_html_tags($desc);
		$level = strip_html_tags($level);
		$jenis = strip_html_tags($jenis);

		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$rsTemp=mysql_query("SELECT nama, level FROM kompetensi WHERE nama='".$nama."' AND level='".$level."'", $dbLink);
			if(mysql_num_rows($rsTemp)>0)
			{
				throw new Exception('Nama kompetensi dengan level tersebut sudah digunakan. Silakan gunakan nama yang belum terpakai atau dengan level yang berbeda.');
			}
			else
			{ 
				$q = "INSERT INTO kompetensi (nama, deskripsi, level, jenis, aktif) ";
				$q.= "VALUES ('".$nama."','".$desc."','".$level."','".$jenis."','Y');";
			
				if (!mysql_query($q, $dbLink))
				{	
					throw new Exception('Gagal menambah database'); 
				}
			}
			$this->strResults="Sukses Tambah Data Kompetensi ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			$this->strResults="Gagal Tambah Data Kompetensi - ".$e->getMessage().'<br/>';
			$result = @mysql_query('ROLLBACK', $dbLink);
			$result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		return $this->strResults;
	}

	function changeSyaratEkstra($kode, $syarats){
		global $dbLink;

		$syarat = array();
		$syarat = $syarats;

		$rsTemp=mysql_query("SELECT jenis, ruang_lingkup_id, posisi_id, jumlah_min FROM syarat_ekstra WHERE kompetensi_id='".$kode."'", $dbLink);
		if(mysql_num_rows($rsTemp)>0)
		{
			throw new Exception('Syarat tersebut sudah terdapat pada kompetensi ini. Silakan tambahkan syarat yang berbeda.');
		}
		else
		{ 
			$q = "INSERT INTO syarat_ekstra (jenis, ruang_lingkup_id, posisi_id, jumlah_min) ";
			$q.= "VALUES ('".$syarat["jenis"]."','".$syarat["ruang_lingkup"]."','".$syarat["posisi"]."','".$syarat["jumlah_min"]."','Y');";
		}
	}
	
	function editKompetensi(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateKompetensi($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Ubah Data Kompetensi - ".$this->strResults;
			return $this->strResults;
		}
		$id = $params["txtId"];
		$nama = $params["txtNama"];
		$desc = $params["txtDesc"];
		$level = $params["rdoLevel"];
		$jenis = $params["rdoJenis"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$id = stripslashes($id);
			$nama = stripslashes($nama);
			$desc = stripslashes($desc);
			$level = stripslashes($level);
			$jenis = stripslashes($jenis);
		}
		$id = stripslashes($id);
		$nama=mysql_real_escape_string($nama, $dbLink);
		$desc = mysql_real_escape_string($desc, $dbLink);
		$level = mysql_real_escape_string($level, $dbLink);
		$jenis = mysql_real_escape_string($jenis, $dbLink);

		$id = stripslashes($id);
		$nama=strip_html_tags($nama);
		$desc = strip_html_tags($desc);
		$level = strip_html_tags($level);
		$jenis = strip_html_tags($jenis);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE kompetensi SET nama='".$nama."', deskripsi='".$desc."', level='".$level."', jenis='".$jenis."'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat mengubah data kompetensi di database.');
			}
			$this->strResults="Sukses Ubah Data Kompetensi";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Ubah Data Kompetensi - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		$this->strResults .= "&kode=".md5($id);
		return $this->strResults;
	}
	
	function deleteKompetensi(&$params)
	{
		global $dbLink;

		$id = $params['txtId'];

		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateDeleteKompetensi($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Kompetensi - ".$this->strResults;
			return $this->strResults;
		}

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc($id)) 
		{
			$id = stripslashes($id);
		}
		$id = mysql_real_escape_string($id, $dbLink);
		$id = strip_html_tags($id);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE kompetensi SET aktif='T'";
			$q.= " WHERE id='".$id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat menghapus data kompetensi di database.');
			}
			$this->strResults="Sukses Hapus Data Kompetensi ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Hapus Data Kompetensi - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		
		return $this->strResults;
	}

	function validateSyarat(&$params) 
	{
		$temp=TRUE;
		//nama kompetensi harus diisi
		if($params["rdoJenis"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Jenis harus diisi!<br/>";
			$temp=FALSE;
		}
		//level diisi
		if($params["cboRuangLingkupl"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Ruang Lingkup harus diisi!<br/>";
			$temp=FALSE;
		}
		//jenis harus diisi
		if($params["cboPosisi"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Posisi harus diisi!<br/>";
			$temp=FALSE;
		}
		//jenis harus diisi
		if($params["rdoJumlah"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Jumlah harus diisi!<br/>";
			$temp=FALSE;
		}

		return $temp;
	}

	function validateDeleteSyarat($kode) 
	{
		global $dbLink;
		
		$temp=FALSE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}
		
		return $temp;
	}

	function addSyarat(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateSyarat($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Tambah Data Syarat - ".$this->strResults;
			return $this->strResults;
		}
		$jenis = $params["rdoJenis"];
		$ruang_lingkup = $params["cboRuangLingkup"];
		$posisi = $params["cboPosisi"];
		$jumlah_min = $params["txtJumlah"];
		$kode = $params["txtId"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$jenis = stripslashes($jenis);
			$ruang_lingkup = stripslashes($ruang_lingkup);
			$posisi = stripslashes($posisi);
			$jumlah_min = stripslashes($jumlah_min);
			$kode = stripslashes($kode);
		}
		$jenis=mysql_real_escape_string($jenis, $dbLink);
		$ruang_lingkup = mysql_real_escape_string($ruang_lingkup, $dbLink);
		$posisi = mysql_real_escape_string($posisi, $dbLink);
		$jumlah_min = mysql_real_escape_string($jumlah_min, $dbLink);
		$kode = mysql_real_escape_string($kode, $dbLink);

		$jenis=strip_html_tags($jenis);
		$ruang_lingkup = strip_html_tags($ruang_lingkup);
		$posisi = strip_html_tags($posisi);
		$jumlah_min = strip_html_tags($jumlah_min);
		$kode = strip_html_tags($kode);

		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$rsTemp=mysql_query("SELECT * FROM syarat_ekstra WHERE jenis='".$jenis."' AND ruang_lingkup_id='".$ruang_lingkup."' AND posisi_id='".$posisi."' AND jumlah_min='".$jumlah_min."'", $dbLink);
			if(mysql_num_rows($rsTemp)>0)
			{
				throw new Exception('Syarat tersebut sudah dicantumkan pada kompetensi ini. Silakan tambahkan syarat lain yang berbeda.');
			}
			else
			{ 
				$q = "INSERT INTO syarat_ekstra (jenis, ruang_lingkup_id, posisi_id, jumlah_min, kompetensi_id) ";
				$q.= "VALUES ('".$jenis."','".$ruang_lingkup."','".$posisi."','".$jumlah."','".$kode."');";
			
				if (!mysql_query($q, $dbLink))
				{	
					throw new Exception('Gagal menambah database'); 
				}
			}
			$this->strResults="Sukses Tambah Data Syarat";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			$this->strResults="Gagal Tambah Data Syarat - ".$e->getMessage().'<br/>';
			$result = @mysql_query('ROLLBACK', $dbLink);
			$result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		$this->strResults .= "&kode=".md5($kode);
		return $this->strResults;
	}

	function editSyarat(&$params) 
	{
		global $dbLink;
		
		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateSyarat($params))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Ubah Data Syarat - ".$this->strResults;
			return $this->strResults;
		}
		$jenis = $params["rdoJenis"];
		$ruang_lingkup = $params["cboRuangLingkup"];
		$posisi = $params["cboPosisi"];
		$jumlah_min = $params["rdoJumlah"];
		$kode = $params["txtId"];
		$kompetensi_id = $params["txtKompetensi"];

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc()) 
		{
			$jenis = stripslashes($jenis);
			$ruang_lingkup = stripslashes($ruang_lingkup);
			$posisi = stripslashes($posisi);
			$jumlah_min = stripslashes($jumlah_min);
			$kode = stripslashes($kode);
			$kompetensi_id = stripslashes($kompetensi_id);
		}
		$jenis=mysql_real_escape_string($jenis, $dbLink);
		$ruang_lingkup = mysql_real_escape_string($ruang_lingkup, $dbLink);
		$posisi = mysql_real_escape_string($posisi, $dbLink);
		$jumlah_min = mysql_real_escape_string($jumlah_min, $dbLink);
		$kode = mysql_real_escape_string($kode, $dbLink);
		$kompetensi_id = mysql_real_escape_string($kompetensi_id, $dbLink);

		$jenis=strip_html_tags($jenis);
		$ruang_lingkup = strip_html_tags($ruang_lingkup);
		$posisi = strip_html_tags($posisi);
		$jumlah_min = strip_html_tags($jumlah_min);
		$kode = strip_html_tags($kode);
		$kompetensi_id = strip_html_tags($kompetensi_id);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "UPDATE syarat_ekstra SET jenis='".$jenis."', ruang_lingkup_id='".$ruang_lingkup."', posisi_id='".$posisi."', jumlah_min='".$jumlah_min."'";
			$q.= " WHERE kompetensi_id='".$kompetensi_id."' AND id='".$kode."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat mengubah data syarat di database.');
			}
			$this->strResults="Sukses Ubah Data Syarat";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Ubah Data Syarat - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		$this->strResults .= "&kode=".md5($kompetensi_id);
		return $this->strResults;
	}

	function deleteSyarat(&$params)
	{
		global $dbLink;

		$id = $params['txtId'];
		$kompetensi_id = $params['txtKompetensi'];

		//Jika input tidak valid, langsung kembalikan pesan error ke user ($this->strResults)
		if(!$this->validateDeleteKompetensi($id))
		{	//Pesan error harus diawali kata "Gagal"
			$this->strResults="Gagal Hapus Data Syarat - ".$this->strResults;
			return $this->strResults;
		}

		//Secure parameter from SQL injection
		if(get_magic_quotes_gpc($id)) 
		{
			$id = stripslashes($id);
			$kompetensi_id = stripslashes($kompetensi_id);
		}
		$id = mysql_real_escape_string($id, $dbLink);
		$kompetensi_id = mysql_real_escape_string($kompetensi_id, $dbLink);

		$id = strip_html_tags($id);
		$kompetensi_id = strip_html_tags($kompetensi_id);
		
		try
		{
			$result = @mysql_query('SET AUTOCOMMIT=0', $dbLink);
			$result = @mysql_query('BEGIN', $dbLink);
			if (!$result) {
				throw new Exception('Could not begin transaction');
			}
			
			$q = "DELETE FROM syarat_ekstra";
			$q.= " WHERE id='".$id."' AND WHERE kompetensi_id='".$kompetensi_id."';";
			if(!mysql_query($q, $dbLink))
			{
				throw new Exception('Tidak dapat menghapus data syarat di database.');
			}
			$this->strResults="Sukses Hapus Data Syarat ";
			@mysql_query("COMMIT", $dbLink);
		}
		catch(Exception $e) 
		{
			  $this->strResults="Gagal Hapus Data Syarat - ".$e->getMessage().'<br/>';
			  $result = @mysql_query('ROLLBACK', $dbLink);
			  $result = @mysql_query('SET AUTOCOMMIT=1', $dbLink);
		}
		$this->strResults .= "&kode=".md5($kompetensi_id);
		return $this->strResults;
	}

	function validateEkstraMahasiswa(&$params) 
	{
		$temp=TRUE;
		//nama kompetensi harus diisi
		if($params["rdoJenis"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Jenis harus diisi!<br/>";
			$temp=FALSE;
		}
		//level diisi
		if($params["cboRuangLingkupl"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Ruang Lingkup harus diisi!<br/>";
			$temp=FALSE;
		}
		//jenis harus diisi
		if($params["cboPosisi"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Posisi harus diisi!<br/>";
			$temp=FALSE;
		}
		//jenis harus diisi
		if($params["rdoJumlah"]=="" && $params['txtMode'] == "Add")
		{
			$this->strResults.="Jumlah harus diisi!<br/>";
			$temp=FALSE;
		}

		return $temp;
	}

	function validateDeleteEkstraMahasiswa($kode) 
	{
		global $dbLink;
		
		$temp=FALSE;
		if(empty($kode))
		{
			$this->strResults.="Kode tidak ditemukan!<br/>";
			$temp=FALSE;
		}
		
		return $temp;
	}
}
?>