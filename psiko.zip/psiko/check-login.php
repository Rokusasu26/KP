<?php

define('validSession', 1);
$tempResult ="";

session_name("UBAYA");
session_start();

require_once('config.php');

require_once('./function/secureParam.php');

if (isset($_POST['txtUserID'])) {
	
	require_once('./class/c_login.php');
    $tmpLogin = new c_login();

    $tempResult = $tmpLogin->validateUser($_POST['txtUserID']);
	
	if ($tempResult == 10){
         $tempResult = "User ID atau Password tidak valid !";
	}	
}
echo $tempResult;
?>
	