<div class="content-wrapper">
  <section class="content">
    <div class="box box-primary">
      <div class="box-header with-border primary">
        <h3 class="box-title" style="color:blue">API</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                  title="Collapse">
            <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body">
        <code>
          $.ajax({<br>
            &nbsp;&nbsp;&nbsp;url : "function/api.php",<br>
            &nbsp;&nbsp;&nbsp;type: "POST",<br>
            &nbsp;&nbsp;&nbsp;data: {proses:"keluar"},<br>
            &nbsp;&nbsp;&nbsp;success: function(data) {<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;console.log(data);<br>
            &nbsp;&nbsp;&nbsp;},<br>
            &nbsp;&nbsp;&nbsp;error: function(data) {<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;alert('Send Failed !!!');<br>
            &nbsp;&nbsp;&nbsp;}<br>
          })
        </code>
      </div>

      <div class="box-footer">
        <h4>Keterangan :</h4>
        <table>
        <tr>
          <th>url</th>
          <td>= Alamat API</td>
        </tr>
        <tr>
          <th>data</th>
          <td>= Berisi data yang akan di proses pada API</td>
        </tr>
        <tr>
          <th>proses</th>
          <td>= Kondisi yang digunakan pada api</td>
        </tr>
        </table>
      </div>
    </div>
  </section>
</div>



<!-- Main scripts -->
<script src="<?= $base_url ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?= $base_url ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= $base_url ?>/dist/js/app.min.js"></script>
<!-- End Main scripts -->