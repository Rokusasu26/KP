<div class="content-wrapper">
  <section class="content">
    <div class="box box-primary">
      <div class="box-header with-border primary">
        <h3 class="box-title" style="color:blue">Title</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                  title="Collapse">
            <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body">
        <code>$(document).ajaxStart(function() { Pace.restart(); });</code>
      </div>

      <div class="box-footer">
        Footer
      </div>
    </div>
  </section>
</div>



<!-- Main scripts -->
<script src="<?= $base_url ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?= $base_url ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= $base_url ?>/dist/js/app.min.js"></script>
<!-- End Main scripts -->