<div class="content-wrapper">
  <section class="content">
    <div class="box box-primary" id="tambah">
      <div class="box-header with-border primary">
        <h3 class="box-title" style="color:blue">Tambah</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                  title="Collapse">
            <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body">
        <code>tambah($dbLink,$tabel,$kolom,$data);</code>
      </div>

      <div class="box-footer">
        <h4>Keterangan :</h4>
        <table>
        <tr>
          <th>$dbLink</th>
          <td>= Koneksi database</td>
        </tr>
        <tr>
          <th>$tabel</th>
          <td>= Nama tabel yang ingin ditambah data</td>
        </tr>
        <tr>
          <th>$kolom</th>
          <td>= Nama kolom yang ingin ditambah data</td>
        </tr>
        <tr>
          <th>$data</th>
          <td>= Data yang akan ditambahkan</td>
        </tr>
        </table>
        <hr>
        <h4>Penggunaan :</h4>
        <code>
          $kolom = ["id" , "nama"];<br>
          $kolom = implode(", ",$kolom);<br><br>
          
          $data = [$_POST['id'] , $_POST['nama']];<br>
          $data = implode("','",$data);<br><br>

          tambah($dbLink,'menu',$kolom,$data);
        </code>
      </div>
    </div>

    <div class="box box-primary" id="tambah1">
      <div class="box-header with-border primary">
        <h3 class="box-title" style="color:blue">Tambah 1</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                  title="Collapse">
            <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body">
        <code>tambah1($dbLink,$tabel,$kolom,$data);</code>
      </div>

      <div class="box-footer">
        <h4>Keterangan :</h4>
        <table>
        <tr>
          <th>$dbLink</th>
          <td>= Koneksi database</td>
        </tr>
        <tr>
          <th>$tabel</th>
          <td>= Nama tabel yang ingin ditambah data</td>
        </tr>
        <tr>
          <th>$kolom</th>
          <td>= Nama kolom yang ingin ditambah data</td>
        </tr>
        <tr>
          <th>$data</th>
          <td>= Data yang akan ditambahkan</td>
        </tr>
        </table>
        <hr>
        <h4>Penggunaan :</h4>
        <code>
          $kolom = ["id" , "nama"];<br>
          $kolom = implode(", ",$kolom);<br><br>
          
          $data = [$_POST['id'] , $_POST['nama']];<br>
          $data = implode("','",$data);<br><br>

          tambah($dbLink,'menu',$kolom,$data);
        </code>
        <hr>
        <h4>Note :</h4>
        <p>Fungsi ini digunakan untuk menambah atau memperbarui data yang sudah ada</p>
      </div>
    </div>

    <div class="box box-primary" id="tampil">
      <div class="box-header with-border primary">
        <h3 class="box-title" style="color:blue">Tampil</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                  title="Collapse">
            <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body">
        <code>tampil($dbLink,$kolom1,$tabel,$urutan);</code>
      </div>

      <div class="box-footer">
        <h4>Keterangan :</h4>
        <table>
        <tr>
          <th>$dbLink</th>
          <td>= Koneksi database</td>
        </tr>
        <tr>
          <th>$kolom1</th>
          <td>= Isi kolom yang ingin ditampilkan</td>
        </tr>
        <tr>
          <th>$tabel</th>
          <td>= Nama tabel yang ditampilkan</td>
        </tr>
        <tr>
          <th>$urutan</th>
          <td>= Nama kolom yang dijadikan urutan</td>
        </tr>
        </table>
      </div>
    </div>

    <div class="box box-primary" id="tampil1">
      <div class="box-header with-border primary">
        <h3 class="box-title" style="color:blue">Tampil 1</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                  title="Collapse">
            <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body">
        <code>tampil1($dbLink,$kolom1,$tabel,$kolom2,$kondisi,$data,$urutan);</code>
      </div>

      <div class="box-footer">
        <h4>Keterangan :</h4>
        <table>
        <tr>
          <th>$dbLink</th>
          <td>= Koneksi database</td>
        </tr>
        <tr>
          <th>$kolom1</th>
          <td>= Isi kolom yang ingin ditampilkan</td>
        </tr>
        <tr>
          <th>$tabel</th>
          <td>= Nama tabel yang ditampilkan</td>
        </tr>
        <tr>
          <th>$kolom2</th>
          <td>= Nama kolom yang dijadikan kondisi</td>
        </tr>
        <tr>
          <th>$kondisi</th>
          <td>= Operator yang dijadikan kondisi (Contoh : = , != , < , >)</td>
        </tr>
        <tr>
          <th>$data</th>
          <td>= Data sebagai nilai kondisi</td>
        </tr>
        <tr>
          <th>$urutan</th>
          <td>= Nama kolom yang dijadikan urutan</td>
        </tr>
        </table>
      </div>
    </div>
  </section>
</div>



<!-- Main scripts -->
<script src="<?= $base_url ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?= $base_url ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= $base_url ?>/dist/js/app.min.js"></script>
<!-- End Main scripts -->