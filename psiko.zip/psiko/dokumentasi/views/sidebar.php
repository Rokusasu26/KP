<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Sidebar Active //
$beranda    = "";
$profil     = "";
$pengaturan = ""; $pengaturan_pengguna = "";

switch ($menu) {
  case 'beranda':
    $beranda = "active";
    break;
  case 'profil':
    $profil = "active";
    break;
  case 'pengguna':
    $pengaturan = "active"; $pengaturan_pengguna = "active";
    break;
}
// Sidebar Active //
?>
<aside class="main-sidebar">
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?= $base_url ?>/dist/img/sukses.png" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p>HELP</p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>
    <!-- search form -->
    <!-- <form action="#" method="get" class="sidebar-form">
      <div class="input-group">
        <input type="text" name="q" class="form-control" placeholder="Search...">
            <span class="input-group-btn">
              <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
              </button>
            </span>
      </div>
    </form> -->
    <!-- /.search form -->
    
    <ul class="sidebar-menu">
      <li class="header">MAIN NAVIGATION</li>
      <li class="<?= $beranda ?>"><a href="<?= $base_url ?>/dokumentasi/"><i class="fa fa-dashboard"></i> <span>Home</span></a></li>
      <li class="<?= $profil ?>"><a href="<?= $url ?>/?menu=api"><i class="fa fa-gear"></i> <span>Api</span></a></li>

      <li class="treeview <?= $pengaturan ?>">
        <a href="#">
          <i class="fa fa-gear"></i> <span>Settings</span>
          <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
        </a>
        <ul class="treeview-menu">
          <li class="<?= $pengaturan_pengguna ?>"><a href="<?= $base_url ?>/setting-profile.html"><i class="fa fa-circle-o text-aqua"></i> User</a></li>
        </ul>
      </li>

      <li class="treeview">
          <a href="#">
            <i class="fa fa-gear"></i> <span>Function</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> Level One</a></li>
            <li class="treeview">
              <a href="#"><i class="fa fa-circle-o text-aqua"></i> Model
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?= $url ?>/?menu=fungsi&#tambah"><i class="fa fa-circle-o"></i> Tambah</a></li>
                <li><a href="<?= $url ?>/?menu=fungsi&#tambah1"><i class="fa fa-circle-o"></i> Tambah1</a></li>
                <li><a href="<?= $url ?>/?menu=fungsi&#tampil"><i class="fa fa-circle-o"></i> Tampil</a></li>
                <li><a href="<?= $url ?>/?menu=fungsi&#tampil1"><i class="fa fa-circle-o"></i> Tampil 1</a></li>
              </ul>
            </li>
          </ul>
        </li>
    </ul>
  </section>
</aside>