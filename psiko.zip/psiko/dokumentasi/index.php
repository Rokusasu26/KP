<?php
define("BASEPATH",1); # agar tidak bisa akses file secara langsung;
$base_url = "http://localhost/sister";
$url      = "http://localhost/sister/dokumentasi";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Aditya">
    <meta name="robots" content="index,follow">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dokumentasi</title>
    <link rel="shortcut icon" href="<?= $base_url ?>/dist/img/sukses.png">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <link rel="stylesheet" href="<?= $base_url ?>/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

    <link href="<?= $base_url ?>/dist/css/AdminLTE.min.css" rel="stylesheet">
    
    <link href="<?= $base_url ?>/dist/css/skins/_all-skins.min.css" rel="stylesheet">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <?php
    if (empty($_GET['menu'])) {
        $menu = 'beranda';
    } else {
        $menu = $_GET['menu'];
    }

    include_once "views/topmenu.php";

    include_once "views/sidebar.php";

    switch ($menu) {
        case 'beranda':
            include_once "views/page/beranda.php";
            break;
        case 'fungsi':
            include_once "views/page/fungsi.php";
            break;
        case 'api':
            include_once "views/page/api.php";
            break;
        default:
            echo "Kosong";
            break;
    }
    ?>

    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b><?= gmdate('d-M-Y H:i:s A', time()+60*60*7) ?></b>
        </div>
        <strong>Copyright &copy; <a href="#">SIM</a>.</strong> All rights reserved.
    </footer>

    <div class="control-sidebar-bg"></div>
</div>
<script src="<?= $base_url ?>/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="<?= $base_url ?>/plugins/fastclick/fastclick.js"></script>
<script src="<?= $base_url ?>/dist/js/demo.js"></script>
</body>
</html>