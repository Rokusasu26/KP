<?php
//Memastikan file ini tidak diakses secara langsung (direct access is not allowed)
defined('validSession') or die('Restricted access');

require_once('./config.php');
require_once('./class/c_user.php');

function menu() {
    global $dbLink;
    $filter = '';
    
    if (!empty($_GET['page'])) {
        $db_menu = "SELECT * FROM menu WHERE link = '".$_GET['page']."'";
        $d_menu  = mysql_query($db_menu, $dbLink);
        $d_m     = mysql_fetch_assoc($d_menu);
        $page    = substr($d_m['link'],5);
        $k_page  = substr($d_m['kodeMenu'],0,2);
    } else {
        $page   = '';
        $k_page = '';
    }

    $privilege = secureParam($_SESSION["my"]->privilege, $dbLink);

    $filter = " INNER JOIN groupPrivilege gp ON m.kodeMenu=gp.kodeMenu AND gp.kodeGroup='".$privilege."'";

    $q = "SELECT DISTINCT m.kodeMenu, m.judul, m.link FROM menu m".$filter." WHERE m.aktif='Y' AND m.kodeMenu IN (".$_SESSION["my"]->menus.") ORDER BY m.kodeMenu;";
    $cari_menu = mysql_query($q, $dbLink);
    ?>

    <?php
    while ($menu = mysql_fetch_array($cari_menu)) {
        if (strlen($menu['link']) == 0) {
            $menuLink = "index.php";
        } else {
            $menuLink = "index.php?page=".$menu['link'];
        }
        ?>
        <li class="treeview <?php if ($k_page == $menu['kodeMenu']) { echo "active"; } ?>">
            <a href="<?= $menuLink; ?>">
                <i class="fa fa-gear"></i>
                <span><?= $menu['judul']; ?></span>
                <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
                <ul class="treeview-menu">
                    <?php
                    $sub_q = "SELECT * FROM menu INNER JOIN (groupPrivilege INNER JOIN userGroup ON groupPrivilege.kodeGroup = userGroup.kodeGroup) ON menu.kodeMenu = groupPrivilege.kodeMenu WHERE userGroup.kodeUser = '".$_SESSION["my"]->id."' AND menu.kodeMenu LIKE '".$menu['kodeMenu'].".%' AND menu.aktif='Y' ORDER BY menu.kodeMenu";
                    $cari_sub_menu = mysql_query($sub_q, $dbLink);
                    while ($sub_menu = mysql_fetch_array($cari_sub_menu)) {
                        if (strlen($sub_menu['link']) == 0) {
                            $tempLink = '';
                        } else {
                            $tempLink = "index.php?page=".$sub_menu['link'];
                        }
                        
                        $list_page = substr($sub_menu['link'],5);
                        ?>
                        <li class="<?php if ($page == $list_page) { echo "active"; } ?>"><a href="<?= $tempLink; ?>"><i class="fa fa-circle-o text-aqua"></i> <?= $sub_menu['judul']; ?></a></li>
                    <?php } ?>
                </ul>
            </a>
        </li>
    <?php } ?>
    <!-- <li><a href="index.php?page=login_detail&eventCode=20"><i class="fa fa-sign-out"></i><span>Log Out</span></a></li> -->
<?php } ?>

