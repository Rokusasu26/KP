<?php
	function ambilData($select="select", $from="from", $where="where")
	{
		
	}
?>
