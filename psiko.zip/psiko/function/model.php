<?php
defined('validSession') or die('Restricted access');

function tambah($dbLink,$tabel,$kolom,$data) {
	$tabel_data = mysql_query("INSERT INTO $tabel (".$kolom.") VALUES ('".$data."')", $dbLink) or die("Gagal Tambah !");
}

function tambah1($dbLink,$tabel,$kolom,$data) {
	$tabel_data = mysql_query("REPLACE INTO $tabel (".$kolom.") VALUES ('".$data."')", $dbLink) or die(mysql_error());
}



function tampil($dbLink,$kolom1,$tabel,$urutan) {
    $query = mysql_query("SELECT $kolom1 FROM $tabel ORDER BY $urutan", $dbLink);
	$isi   = mysql_num_rows($query);
	if (!empty($isi)) {
		return $query;
	} else {
		return $isi;
	}
}

function tampil1($dbLink,$kolom1,$tabel,$kolom2,$kondisi,$data,$urutan) {
    $query = mysql_query("SELECT $kolom1 FROM $tabel WHERE $kolom2 $kondisi $data ORDER BY $urutan", $dbLink);
	$isi   = mysql_num_rows($query);
	if (!empty($isi)) {
		return $query;
	} else {
		return $isi;
	}
}

function tampi2($dbLink,$kolom1,$tabel,$urutan,$posisi,$batas) {
    $query = mysql_query("SELECT $kolom1 FROM $tabel ORDER BY $urutan LIMIT $posisi, $batas", $dbLink);
	$isi   = mysql_num_rows($query);
	if (!empty($isi)) {
		return $query;
	} else {
		return $isi;
	}
}
?>