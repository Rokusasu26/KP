<?php
require_once('../config.php' );
require_once('../function/secureParam.php');
switch ($_POST['fungsi']) {
    case "checkKodeMenu":
        $result = mysql_query("select kodeMenu FROM menu WHERE kodeMenu ='" . secureParamAjax($_POST['kodeMenu'], $dbLink) . "'", $dbLink);
        if (mysql_num_rows($result)) {
            echo "yes";
        } else {
            echo "no";
        }
        break;

    case "checkKodeGroup":
        $result = mysql_query("select kodeGroup FROM groups WHERE kodeGroup ='" . secureParamAjax($_POST['kodeGroup'], $dbLink) . "'", $dbLink);
        if (mysql_num_rows($result)) {
            echo "yes";
        } else {
            echo "no";
        }
        break;

    case "checkKodeUser":
        $result = mysql_query("select kodeUser FROM user WHERE kodeUser ='" . secureParamAjax($_POST['kodeUser'], $dbLink) . "'", $dbLink);
        if (mysql_num_rows($result)) {
            echo "yes";
        } else {
            echo "no";
        }
        break;

    case "checkKodeKota":
        if ($_POST['kodeKota'] != "") {
            $result = mysql_query("select kodeKota from kota where kodeKota ='" . strtoupper($_POST['kodeKota']) . "'");
            if (mysql_num_rows($result)) {
                echo "yes";
            } else {
                echo "no";
            }
        } else {
            echo "none";
        }
        break;

    case "ambilDataInisiasi":
        if ($_POST['kodeInisiasi'] != "0") {
            $result = mysql_query("SELECT id, judulKerjasama, namaMitra, deskripsiInisiasi, namaPemohon, satker 
                FROM inisiasi WHERE id ='" . $_POST['kodeInisiasi'] . "'", $dbLink);
            if (mysql_num_rows($result)) {
                $data = mysql_fetch_array($result);
                
                $q_satker = "SELECT idsatker, namasatker FROM ms_satker WHERE idsatker='".$data['satker']."' ";
                $rsSatker = pg_query($dbLinkSinta, $q_satker); 

                $satker = pg_fetch_array($rsSatker);
                 
                echo json_encode(array("hasil"=>"yes", "JudulKerjasama"=>$data['judulKerjasama'], "NamaMitra"=>$data['namaMitra'], 
                    "DeskripsiInisiasi"=>$data['deskripsiInisiasi'], "NamaPemohon"=>$data['namaPemohon'], "Satker"=>$satker['namasatker'] ));
                break;
                
            } else {
                
                $error ="Kode Inisiasi Tidak Valid";
                echo json_encode(array("hasil"=>"no", "JudulKerjasama"=>$error, "NamaMitra"=>$error, 
                    "DeskripsiInisiasi"=>$error, "NamaPemohon"=>$error, "Satker"=>$error )); 
                break;
            }
        }else{
            $error ="";
                echo json_encode(array("hasil"=>"no", "JudulKerjasama"=>$error, "NamaMitra"=>$error, 
                    "DeskripsiInisiasi"=>$error, "NamaPemohon"=>$error, "Satker"=>$error )); 
        } 
        
    break;
    
    case "cobaCek":
        if ($_POST['kodeInisiasi'] != "0") {
            echo "Hasil Test ".$_POST['kodeInisiasi'];
              
        }
        break;

    case "suggestPeneliti":
        $keyword = strval($_POST['query']);
        // $search_param = "{$keyword}%";
        // $conn =new mysqli('localhost', 'root', '' , 'blog_samples');

        // $sql = $conn->prepare("SELECT * FROM tbl_country WHERE country_name LIKE ?");
        // $sql->bind_param("s",$search_param);            
        // $sql->execute();
        // $result = $sql->get_result();

        $result = mysql_query("SELECT idpeneliti, nama FROM peneliti WHERE nama like '%" . $keyword . "%'", $dbLink);

        if (mysql_num_rows($result)) {
            while($data = mysql_fetch_array($result)) {
                $peneliti[] = $row["nama"];
            }
            echo json_encode($peneliti);
        }
        // $conn->close();
        break;

    case "tanggalLibur":
        $tanggalTest = secureParamAjax($_POST['tanggal'],$dbLink);
        $tanggalTest = date('Y-m-d', strtotime($tanggalTest));
        
        $result = mysql_query("SELECT tanggal FROM hariLibur WHERE tanggal ='".$tanggalTest."'", $dbLink);
        if (mysql_num_rows($result)) {
            echo "1";
        } else {
            echo "0";
        }
        break;

    case "checkNamaTujuan":
        if ($_POST['nama'] != "") {
            $result = mysql_query("select nama from tujuanTest where nama ='" . strtoupper($_POST['nama']) . "'");
            if (mysql_num_rows($result)) {
                echo "yes";
            } else {
                echo "no";
            }
        } else {
            echo "none";
        }
        break;

    case "checkNamaLevelJabatan":
        if ($_POST['nama'] != "") {
            $result = mysql_query("select nama from level where nama ='" . strtoupper($_POST['nama']) . "'");
            if (mysql_num_rows($result)) {
                echo "yes";
            } else {
                echo "no";
            }
        } else {
            echo "none";
        }
        break;

    case "checkNamaBiaya":
        if ($_POST['nama'] != "") {
            $result = mysql_query("select nama from biayaTest where nama ='" . strtoupper($_POST['nama']) . "'");
            if (mysql_num_rows($result)) {
                echo "yes";
            } else {
                echo "no";
            }
        } else {
            echo "none";
        }
        break;

    case "checkNamaLaporan":
        if ($_POST['nama'] != "") {
            $result = mysql_query("select nama from bentukLaporan where nama ='" . strtoupper($_POST['nama']) . "'");
            if (mysql_num_rows($result)) {
                echo "yes";
            } else {
                echo "no";
            }
        } else {
            echo "none";
        }
        break;

    case "caripeserta":
        if ($_POST['kodetest'] != "") {
        $text = "";
        $text .= "<option value=''>Pilih Peserta...</option>";
        $result = mysql_query("select p1.idpesertaTest_has_Test, p2.nik, CONCAT(p2.gelarDepan, ' ', p2.nama, ' ', p2.gelarBelakang) as nama
                                from pesertaTest_has_Test p1 join peserta p2 on p1.pesertaTest_nik = p2.nik
                                where p1.Test_idTest = '".secureParamAjax($_POST['kodetest'], $dbLink)."' ");
        if (mysql_num_rows($result) > 0) {
            while ($query_data = mysql_fetch_array($result)) {
                $text .= "<option value=".$query_data["idpesertaTest_has_Test"].">".$query_data["nama"]."</option>";
            }
            echo $text;
        }
    }
    break;

    case "caribiaya":
        if ($_POST['idpsertatest'] != "") {
        $text = "";
        $text .= "<option value=''>Pilih Biaya...</option>";
        $result = mysql_query("select p1.idpesertaTest_has_biayaTest, p2.nama
                                from pesertaTest_has_biayaTest p1 join biayaTest p2 on p1.biayaTest_idbiayaTest = p2.idbiayaTest
                                where p1.idpesertaTest_has_Test = '".secureParamAjax($_POST['idpsertatest'], $dbLink)."' ");
        if (mysql_num_rows($result) > 0) {
            while ($query_data = mysql_fetch_array($result)) {
                $text .= "<option value=".$query_data["idpesertaTest_has_biayaTest"].">".$query_data["nama"]."</option>";
            }
            echo $text;
        }
    }
    break;
}
?>