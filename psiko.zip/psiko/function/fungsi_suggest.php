<?php	
require_once('../config.php' );
require_once('../function/secureParam.php');	
	// $keyword = strval($_POST['query']);
	// $search_param = "{$keyword}%";
	// $conn =new mysqli('localhost', 'root', '' , 'blog_samples');

	// $sql = $conn->prepare("SELECT * FROM tbl_country WHERE country_name LIKE ?");
	// $sql->bind_param("s",$search_param);			
	// $sql->execute();
	// $result = $sql->get_result();
	// if ($result->num_rows > 0) {
	// 	while($row = $result->fetch_assoc()) {
	// 	$countryResult[] = $row["country_name"];
	// 	}
	// 	echo json_encode($countryResult);
	// }
	// $conn->close();
	$keyword = secureParamAjax($_POST['query']);
        // $search_param = "{$keyword}%";
        // $conn =new mysqli('localhost', 'root', '' , 'blog_samples');

        // $sql = $conn->prepare("SELECT * FROM tbl_country WHERE country_name LIKE ?");
        // $sql->bind_param("s",$search_param);            
        // $sql->execute();
        // $result = $sql->get_result();

        $result = mysql_query("SELECT idpeneliti, nama FROM peneliti WHERE nama like '%" . $keyword . "%'", $dbLink);

        if (mysql_num_rows($result)) {
            while($data = mysql_fetch_array($result);) {
                $peneliti[] = $data["nama"];
            }
            echo json_encode($peneliti);
        }
        // $conn->close();
?>