<?php 
/*********** Database Settings ***********/
require_once('function/mysql.php'); # u/ PHP 7

$dbHost = 'localhost';
$dbName = 'fw_siska'; //untuk di server

$dbUser = 'root';
$dbPass = '';

$passSalt = 'UFqPNrZENKSQc5yc';

//Default database link
$dbLink = mysql_connect($dbHost,$dbUser,$dbPass, true)or die('Could not connect: ' . mysql_error());
mysql_query("SET NAMES 'UTF8'");

if(!mysql_select_db($dbName,$dbLink))
{
    die('Database Connection Failed!');
}

/*********** Email Settings ***********/
$mailFrom = 'adm_sim@ubaya.ac.id';

$mailSupport = 'adm_sim@ubaya.ac.id';

/*********** Display Settings ***********/
$siteTitle = 'Sertifikasi Psikologi';
$recordPerPage = 10;

$wajibIsiKeterangan ='<font style="color:#FF0000; font-weight:bold">Field Bertanda * Wajib Diisi</font>';
$wajibIsiSimbol = '<font style="color:#FF0000; font-weight:bold">&nbsp;&nbsp;*</font>';
$SITUS = "";
$base_url = "http://localhost/psiko";

// define('CONST_FOLDER', "/var/www/ubaya");
define('CONST_FOLDER', ".");
?>
